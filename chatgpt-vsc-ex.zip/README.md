# AI Workspace Bridge

Custom language model provider for VS Code chat.

## Features

- Registers a custom chat model named "Workspace Agent"
- Streams word-by-word responses from a mock backend
- Logs activity to a dedicated VS Code output channel

## Development

```bash
npm install
npm run build
```

Launch the extension using VS Code's "Run Extension" configuration.

## Usage

1. Open the VS Code Chat view.
2. Select "Workspace Agent" from the model picker.
3. Send a prompt.

Mock behavior:

- If the prompt contains "FastAPI", response: "FastAPI is a modern Python framework for building APIs."
- If the prompt contains "SQLAlchemy", response: "SQLAlchemy provides ORM and database abstraction for Python."
- If the prompt is "Hello", response: "Hello from Workspace Agent."
- Otherwise response: "You asked: {prompt}"
