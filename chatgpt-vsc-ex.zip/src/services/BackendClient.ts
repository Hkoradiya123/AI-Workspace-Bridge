import * as vscode from "vscode";
import { IBackendClient } from "../types/ChatTypes";
import { Logger } from "../utils/Logger";

export class BackendClient implements IBackendClient {
  public constructor(private readonly logger: Logger) {}

  public async *sendPrompt(prompt: string, _token: vscode.CancellationToken): AsyncIterable<string> {
    this.logger.info("Backend request started");

    const response = this.getMockResponse(prompt);
    const tokens = this.tokenize(response);

    for (const token of tokens) {
      yield token;
    }

    this.logger.info("Backend request finished");
  }

  private getMockResponse(prompt: string): string {
    const normalized = prompt.trim().toLowerCase();

    // Treat common mistypes/variants of "hello" as greetings
    if (normalized.startsWith("hell")) {
      return "Hello from Workspace Agent";
    }

    if (normalized.includes("fastapi")) {
      return "FastAPI is a modern Python framework for building APIs.";
    }

    if (normalized.includes("sqlalchemy")) {
      return "SQLAlchemy provides ORM and database abstraction for Python.";
    }

    // If the user asked a question (or started with a question word), return a helpful generic reply
    const firstToken = normalized.split(/\s+/)[0] || "";
    const questionWords = ["what", "how", "why", "when", "where", "who", "can", "should"]; 
    if (normalized.endsWith("?") || questionWords.includes(firstToken)) {
      return "I can help with code explanations, workspace searches, and mock examples — ask about FastAPI, SQLAlchemy, or say Hello.";
    }

    return `You asked: ${prompt}`;
  }

  private tokenize(text: string): string[] {
    const words = text.split(/\s+/).filter(Boolean);

    return words.map((word, index) => {
      const isLast = index === words.length - 1;
      return isLast ? word : `${word} `;
    });
  }
}
